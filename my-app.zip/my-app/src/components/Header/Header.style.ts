import styled from "styled-components";

export const StyledHeader = styled.header`
    margin: 0;
    padding: 2vh 0.5%;
    display: flex;
    justify-content: space-between;
    background-color: black;
    align-items: center;
`