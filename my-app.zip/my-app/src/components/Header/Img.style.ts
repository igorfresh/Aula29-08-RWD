import styled from "styled-components";

export const StyledImg = styled.img`
    margin: 0;
    max-width: 50px;
    width: 15%;
    padding-left: 1vw;
`