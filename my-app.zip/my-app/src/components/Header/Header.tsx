import Logo from "../../assets/logo-brix.png"
import { StyledHeader } from "./Header.style"
import { StyledImg } from "./Img.style"
import { StyledSpan } from "./Span.style"

interface HeaderProps {
    userName: string
    userImage?: string
}

export const Header = ({ userName, /**userImage =""**/ }: HeaderProps) => {
    return (
        <header>
            <StyledHeader>
                <StyledImg src={Logo} alt="Logotipo Brix" />
                <StyledSpan>Olá, {userName}</StyledSpan>
            </StyledHeader>
        </header>
    )
}