import styled from "styled-components";

export const StyledSpan = styled.span`
    margin: 0;
    font-size: 20px;
    font-weight: 700;
    font-family: Arial, Helvetica, sans-serif;
    color: white;
`