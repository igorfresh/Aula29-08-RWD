import { useState, useEffect } from "react"


interface AddressDataProps{
    addressData: AddressProps
}

export const AddressForm = ({addressData}: AddressDataProps) => {
    
const [postalCode, setPostalCode] = useState (addressData.cep)
const [streetName, setStreetName] = useState (addressData.street)
const [neighborhood, setNeighborhood] = useState (addressData.neighboorhood)
const [cityName, setCityName] = useState (addressData.city)
const [stateName, setStateName] = useState (addressData.state)

useEffect(() => {
    setPostalCode(addressData.cep)
}, [addressData])

    return (
        <form action="">
            <label htmlFor="">CEP</label>
            <input type="text" name="" id="" value={postalCode} />
            <br/>
            <label htmlFor="">Logradouro</label>
            <input type="text" name="" id=""value={streetName}/>
            <br/>
            <label htmlFor="">Bairro</label>
            <input type="text" value={neighborhood} />
            <br/>
            <label htmlFor="">Cidade</label>
            <input type="text" value={cityName}/>
            <br/>
            <label htmlFor="">Estado</label>
            <input type="text" value={stateName}/>
            <br/>

        </form>
    )

}