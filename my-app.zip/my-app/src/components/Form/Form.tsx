import { useEffect, useLayoutEffect, useState } from "react"

export const Form = () => {
    const [name, setName] = useState("")
    const [surname, setSurname] = useState("")
    const [birthdate, setBirthdate] = useState("")
    const [maritalStatus, setMaritalStatus] = useState("")
    const [cpf, setCpf] = useState(false)
    const [rg, setRg] = useState(false)
    const [terms, setTerms] = useState("")

    const handleChangeName = (event) => {
        setName(event.target.value)
    }

    const handleChangeSurname = (event) => {
        setSurname(event.target.value)
    }

    const handleChangeBirthdate = (event) => {
        setBirthdate(event.target.value)
    }

    const handleMaritalStatus = (event) => {
        setMaritalStatus(event.target.value)
    }

    const handleDocumentCpf = (event) => {
        setCpf(event.target.checked)
    }

    const handleDocumentRg = (event) => {
        setRg(event.target.checked)
    }

    const handleChangeTerms = (event) => {
        setTerms(event.target.checked)
    }

    const handleSave = () => {
        const payload = {
            nome: name,
            sobrenome: surname,
            estado_civil: maritalStatus,
            data_nascimento: birthdate,
            documento: cpf ? 'CPF' : 'RG',
            termos: terms,
        }

        console.log(payload)
    }

    const data = {
        nome: "Maico",
        sobrenome: "Jesgo",
        estado_civil: "Casado",
        data_nascimento: "10/12/1955",
        termos: true,
    }


    useLayoutEffect(() => {
        console.log("Use Layout Effect")
        window.scrollTo(0, 0)
    }, [])

    useEffect(() => {
        const { nome, sobrenome, data_nascimento, estado_civil} = data
        
        setName(nome)
        setSurname(sobrenome)
        setBirthdate(data_nascimento)
        setMaritalStatus(estado_civil)
    }, [])


    return ( 
        <form>
            <div>
                <h3>{name} {surname}, {birthdate}</h3>
                <div>
                    <label htmlFor="name">Nome: </label>
                    <input type="text" id="name" onChange={handleChangeName}/>
                </div>
                <div>
                    <label htmlFor="surname">Sobrenome: </label>
                    <input type="text" id="surname" onChange={handleChangeSurname}/>
                </div>
                <div>
                    <label htmlFor="birthdate">Data de Nascimento: </label>
                    <input type="date" id="birthdate" onChange={handleChangeBirthdate}/>
                </div>
                <div>
                    <label htmlFor="marital-status">Estado civil: </label>
                    <select id="marital-status" onChange={handleMaritalStatus}>
                        <option value="solteiro">Solteiro</option>
                        <option value="casado">Casado</option>
                        <option value="viúvo">Viúvo</option>
                        <option value="divorciado">Divorciado</option>
                    </select>
                </div>
                <div>
                    <fieldset>
                        <legend>Documento: </legend>
                        <input name="document" type="radio" id="CPF" onChange={handleDocumentCpf}/>
                        <label htmlFor="CPF">CPF</label>
                        <input name="document" type="radio" id="CNH" onChange={handleDocumentRg}/>
                        <label htmlFor="CNH">CNH</label>
                    </fieldset>
                </div>
                <div>
                    <input type="checkbox" name="terms" id="terms" onChange={handleChangeTerms} checked={terms}/> 
                    <label htmlFor="terms">Aceito os termos e condições</label>
                </div>
                <button type="button" onClick={handleSave}>Salvar</button>
            </div>
        </form>
    )
}