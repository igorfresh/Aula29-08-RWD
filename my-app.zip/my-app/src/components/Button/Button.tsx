import { StyledButton } from "./Button.style"

interface ButtonProps {
    children: string
    danger?: boolean
    success?: boolean
}

export const Button = ({ children, danger, success, ...rest }: ButtonProps) => {
    return <StyledButton danger={danger} success={success} {... rest}>
        {children}
    </StyledButton>
}

export default Button