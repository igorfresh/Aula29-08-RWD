import styled from "styled-components"

export const StyledButton = styled.button`
    border-radius: 20px;
    padding: 5px;
    margin: 0 5px;
    width: 100px;
    color: white;
    background-color: black;
    cursor: pointer;

    &:hover{
        background-color: darkgray;
        color: white;
        transition: ease-in-out 0.3s;
    }

    &:focus {
        outline: 1px solid blue;
    }

    &:disabled {
        background-color: lightgray;
    }

    ${(props) => props.danger &&`
        background-color: red;
        color: white;
        &:hover{
            background-color: darkred;
        }
    `}

    ${(props) => props.success &&`
        background-color: green;
        color: white;
        &:hover{
            background-color: darkgreen;
        }
    `}
`
