import { useState } from "react"
import Button from "../Button/Button"

interface CounterProps {
    step?: number
    start?: number
}

export const Counter = ({ step = 1 , start = 0 }: CounterProps) => {
    const [count, setCount] = useState(start)
    const [isDisabled, setIsDisabled] = useState(true)
    
    const handleIncrement = () => {
        console.log("Incrementar")
        setCount(count + step)
        setIsDisabled(false)
    }

    const handleDecrement = () => {
        console.log("Decrementar")
        if (count > 0) {
            setCount(count - step);
            if (count - step === 0) {
                setIsDisabled(true);
            }
        }
    }
    
    const handleReset = () => {
        console.log("Resetar")
        setCount(0)
        setIsDisabled(true)
    }

    return (
        <div>
            <Button danger onClick={handleDecrement} disabled={isDisabled}>Decrementar</Button>
            <span>{count}</span>
            <Button success onClick={handleIncrement}>Incrementar</Button>
            <Button onClick={handleReset}>Resetar</Button>
        </div>
    )
}