import { StyledButton } from "../Button/Button.style"

export const IconButton = () => {
    return (
        <StyledButton>Icone</StyledButton>
    )
}

export const IconButton2 = () => {
    return (
        <StyledButton>Icone2</StyledButton>
    )
}