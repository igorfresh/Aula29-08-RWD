// import { Button } from "./components/Button/Button"
// import { IconButton, IconButton2 } from "./components/IconButton/IconButton"
// import MaicoJesgo from './assets/MaicoJesgo.png'
// import { Header } from "./components/Header/Header"
// import { Card } from "./components/Card/Card"
// import { Counter } from "./components/Counter/Counter"
// import { Form } from "./components/Form/Form"
// import { AddressForm } from "./components/AddressForm/AddressForm"
import { Address } from "./pages/Address/Address"

function App() {
  const appName = "Meu App"
  const user = {
    name: 'Maico Jesgo'
  }  

  const products = [
    {id: 8, name: "Banana", value: 10},
    {id: 9, name: "Mamão", value: 12},
    {id: 10, name: "Maçã", value: 8},
  ]
  return (
    <>
      {/* <Header userName={user.name}/>
      <h1>{appName}</h1>
      <img src={user.image} alt={user.name} />
      <p>{user.name}</p>
      <Button success>Salvar</Button>
      <Button danger>Cancelar</Button>
      <IconButton />
      <IconButton2 />
        {products.map((product) => (
          <Card key={product.id}> 
          <h3>{product.name}</h3> 
          <p>{product.value}</p> 
          <Button>Adicionar</Button>
          </ Card>
        ) )}
      <Counter />
      <Form /> */}
      <Address />
    </>
  )
}

export default App
